
  //window.addEventListener('load', function() {
	  
	     

      document.getElementById('network-id-display').textContent = nd;

      fetch(`${sp}client/getsettings${pp}?action=get_settings&network_id=${nd}&read_pass=${rs}`)
          .then(response => response.json())
          .then(data => {
              if (data['show-vpn'] === 'on') {
                  document.getElementById('vpn-settings').classList.add('hidden');
              }
              if (data['show-upcl'] === 'on') {
                  document.getElementById('upcl-settings').classList.add('hidden');
				  
              }
              if (data['show-face'] === 'on') {
                  document.getElementById('face-settings').classList.add('hidden');
              }
              if (data['show-bind'] === 'on') {
                  document.getElementById('bind-settings').classList.add('hidden');
              }
              if (data['show-user-count'] === 'on') {
                  document.getElementById('user-count-settings').classList.add('hidden');
              }
              if (data['show-block-formatted-devices'] === 'on') {
               //   document.getElementById('full-screen-alert').classList.add('hidden');
				  
				                var alertDiv = document.getElementById('full-screen-alert');
                      alertDiv.style.display = 'none';

				  
				  
              }
              if (data['show-block-card-guessing'] === 'on') {
                  document.getElementById('block-card-guessing-settings').classList.remove('hidden');
                  runBlockCardGuessingScript();
              }
          })
       //   .catch(error => console.error('Error fetching settings:', error));
        
          function runBlockCardGuessingScript() {
        //    Config({     "enable-hot-blocker": 0,
            
        //})
          }
   

     
 // });