//window.addEventListener('load', function() {
      fetch(`${sp}client/getpoints${pp}?network_id=${nd}&type=sell_points&read_pass=${rs}`)
          .then(response => response.json())
          .then(data => {
              const pointsDiv = document.getElementById('sell-points');
             pointsDiv.innerHTML = ""; // تفريغ المحتوى السابق
              if (!data.error) {
                  data.forEach(point => {
                      const row = document.createElement('tr');
                      row.innerHTML = `<td>${point.name}</td>`;
                      pointsDiv.appendChild(row);
                  });
              } else {
                 // console.error(data.error);
              }
          })
          .catch(error => {
              console.error('Error fetching sell points:', error);
          });
  //});




