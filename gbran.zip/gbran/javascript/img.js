var cachedImages = []; // ذاكرة مؤقتة لتخزين الصور

function img() {
    if (cachedImages.length > 0) {
       // console.log('Images already loaded.');
        initializeAllSliders();
        return;
    }

    fetch(`${sp}getimg${pp}?network_id=${nd}&type=images&read_pass=${rs}`)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
             //   console.log('No images found.');
                return;
            }

            cachedImages = data; // تخزين الصور في الذاكرة المؤقتة
            initializeAllSliders();
        })
        .catch(error => {
            //console.error('Error fetching images:', error);
        });
}

function initializeAllSliders() {
    initializeSlider('slider-container-top', 'image-indicator-top', 'prev-button-top', 'next-button-top');
    initializeSlider('slider-container', 'image-indicator-vewu', 'prev-buttonvewu', 'next-buttonvewu');
    initializeSlider('image-slider', 'image-indicator', 'prev-button', 'next-button');
}

function initializeSlider(sliderId, indicatorId, prevButtonId, nextButtonId) {
    const slider = document.getElementById(sliderId);
    const indicator = document.getElementById(indicatorId);

    if (!slider || !indicator) {
       // console.error(`Slider or indicator not found for IDs '${sliderId}' and '${indicatorId}'`);
        return;
    }

    let currentIndex = 0;
    let autoSlideInterval;

    // تنظيف المحتوى السابق
    slider.querySelectorAll('img').forEach(img => img.remove());
    indicator.innerHTML = '';

    // إضافة الصور والمؤشرات
    cachedImages.forEach((image, index) => {
        const imgElement = document.createElement('img');
        imgElement.src = `${sp}${image.image_path}`;
        imgElement.style.display = index === 0 ? 'block' : 'none';
        slider.appendChild(imgElement);

        const dot = document.createElement('span');
        dot.className = index === 0 ? 'active' : '';
        dot.dataset.index = index;
        dot.addEventListener('click', () => goToSlide(index));
        indicator.appendChild(dot);
    });

    // إضافة أحداث الأزرار
    const prevButton = document.getElementById(prevButtonId);
    const nextButton = document.getElementById(nextButtonId);

    if (prevButton && nextButton) {
        prevButton.addEventListener('click', () => navigateSlide('prev'));
        nextButton.addEventListener('click', () => navigateSlide('next'));
    }

    // بدء التبديل التلقائي
    startAutoSlide();

    function navigateSlide(direction) {
        const images = slider.getElementsByTagName('img');
        if (images.length === 0) return;

        clearInterval(autoSlideInterval);

        images[currentIndex].style.display = 'none';
        indicator.children[currentIndex].classList.remove('active');

        if (direction === 'next') {
            currentIndex = (currentIndex + 1) % cachedImages.length;
        } else if (direction === 'prev') {
            currentIndex = (currentIndex - 1 + cachedImages.length) % cachedImages.length;
        }

        images[currentIndex].style.display = 'block';
        indicator.children[currentIndex].classList.add('active');
    }

    function goToSlide(index) {
        const images = slider.getElementsByTagName('img');
        if (images.length === 0) return;

        clearInterval(autoSlideInterval);

        images[currentIndex].style.display = 'none';
        indicator.children[currentIndex].classList.remove('active');

        currentIndex = index;

        images[currentIndex].style.display = 'none';
        indicator.children[currentIndex].classList.add('active');
    }

    function startAutoSlide() {
        autoSlideInterval = setInterval(() => {
            navigateSlide('next');
        }, 7000);
    }
}

// بدء تحميل الصور
img();
