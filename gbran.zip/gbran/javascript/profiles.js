//window.addEventListener('load', function() {
    fetch(`${sp}client/getprofiles${pp}?network_id=${nd}&type=prices&read_pass=${rs}`)
        .then(response => response.json())
        .then(data => {
            const profilesDiv = document.getElementById('profiles');
            profilesDiv.innerHTML = ""; // تفريغ المحتوى السابق
            if (!data.error) {
                data.forEach(profile => {
                    const row = document.createElement('tr');
                    row.innerHTML = `<td>${profile.price}</td><td>${profile.time}</td><td>${profile.transfer}</td><td>${profile.validity}</td>`;
                    profilesDiv.appendChild(row);
                });
            } else {
                //console.error(data.error);
            }
        })
        .catch(error => {
           // console.error('Error fetching profiles:', error);
        });
//});

