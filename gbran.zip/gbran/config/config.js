﻿Config({
    "n-n": "  شبكة  ",
    "network-name": "    ",
    "network-title": "",
    "service-number": "774300771",
	    "net-name-en": "",

 "login-type": "user",
	//"login-type": "passwordAsUser",
//	"login-type": "both",
    "news-line": "...:::: اهلاً بكم على شبكة    اللاسلكية .",
"input-type": "password",

//  "input-type": "tel",    
"input-autocomplete": "on",
"dm": 1,
    "input-rm-white-spaces": 1,
    "input-to-lower": 1,
    "input-to-upper": 0,
    "input-to-arabic-numbers": 0,
    "input-only-numbers": 0,
    "input-no-numbers": 0,
    "input-only-alphanumeric": 0,
    "input-to-text-type-when": 0,
    "enable-hot-cookie": 1,
    "enable-hot-blocker": 1,
    "clear-router-cookie": 1,
    "clear-hot-cookie": 1,
    "block-time": 2,
    "try-count": 6,
    "warn-when": 5,
    "warn-message": "تحذير !! عدد محاولاتك الخاطئة اصبح {{tryCounter}} محاولات, عدد المحاولات المسموح بها هي {{tryCount}} محاولات فقط, عدد محاولاتك المتبقية {{restTryCount}} محاولات, سيتم حظرك لمدة {{blockTime}} دقائق اذا تجاوزت العدد المسموح للمحاولات",
    "price-button": true,
    "sell-point-button": true,
    "app-store-status-button": false,
    "show-date-field": true,
    "loan-button": true,
    "redirect-to-esterahah": "http://10.10.10.10", //<---إذا عندك إستراحة اكتب او الصق الرابط داخل علامتين التنصيص الذي قبل هذه العلامتين
   "redirect-to-mobasher": "http://10.10.10.10:85", //<---إذا عندك بث مباشر اكتب او الصق الرابط داخل علامتين التنصيص الذي قبل هذه العلامتين
  //  "app-store-base-url": "http://10.10.10.10", // <---إذا عندك متجر تطبيقات اكتب او الصق الرابط داخل علامتين التنصيص الذي قبل  هذه العلامتين
  // "profiles": [{
         //   "price": "100ريال",
         //  "time": "5ساعات",
         //  "transfer": "400 ميغا",
        //  "validity": "شهر",
    //  },
       
  // ],

    "sell-points": [
        {"name":"جميع المراكز المجاورة"},
      
   ]
})