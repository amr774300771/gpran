const nd = 55;
  const rs = "AHFA09CXR5Q6Z"; 

   const ho =`${hp}${rs}${cm}${sh}${gt}${sh}`;
